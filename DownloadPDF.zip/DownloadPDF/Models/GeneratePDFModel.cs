﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DownloadPDF.Models
{
    public class GeneratePDFModel
    {
        public string PDFContent { get; set; }
        public string PDFLogo { get; set; }
    }
}